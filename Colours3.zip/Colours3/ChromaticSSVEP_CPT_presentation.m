%% Stimulus presentation and response recording for Lindquist et al. (2020)
% Uses Psychtoolbox
% Loads chromatic grating patterns from folder Colours3
% Exports stimulus and response information in appended (unformatted) text
% file and in formatted Excel file

sca;
close all;
clearvars; 
AssertOpenGL;
Screen('Preference', 'SkipSyncTests', 0);
HideCursor;

% change
ID='test';
path = [pwd '\Colours3\'];


s = daq.createSession('ni');                                      % setup the session �� Initialize the session�based interface
                                                                  % to the NI�DAQ device.  This is the only
                                                                  % method supported on 64�bit Windows as of R2015
ch = addDigitalChannel(s,'Dev1', 'Port1/Line0:7', 'OutputOnly');  % Setup an 8�bit range as a channel to which events can be written


%% Letter information

randomletters = ['J', 'C', 'P', 'H', 'V', 'E'];
pairs = ['A', 'X'; 'A', 'B'; 'B', 'X'; 'B', 'M'];
order = 1:5;
l = 'Q';
RT = [];

%% Open screen

doublebuffer = 1;
[windowPr,rect] = Screen('OpenWindow',0,0,[ ]);
Screen('BlendFunction',windowPr,GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
width=rect(RectRight)-rect(RectLeft);
height=rect(RectBottom)-rect(RectTop);
fps=Screen('FrameRate',windowPr);      % frames per second
[center(1), center(2)] = RectCenter(rect);

topPriorityLevel = MaxPriority(windowPr);
Priority(topPriorityLevel);
 
% fixation cross coords
H=width/2; 
H1=width/2-(width/2/60);
H2=width/2+(width/2/60);
V=height/2;
V1=height/2-(width/2/60);
V2=height/2+(width/2/60);
penWidth=2;

% text info and monochrome
white = WhiteIndex(windowPr);
black = BlackIndex(windowPr);
textsize=40;
Font='Arial'; Screen('TextSize',windowPr,textsize); Screen('TextFont',windowPr,Font); Screen('TextColor',windowPr,black);

% parameters for circle
mon_width   = 39;                                                   % horizontal dimension of viewable screen (cm)
v_dist      = 60;                                                   % viewing distance (cm)
ppd = pi * (rect(3)-rect(1)) / atan(mon_width/v_dist/2) / 360;      % pixels per degree
fix_r       = 0.7;                                                  % radius of fixation point (deg)  
fix_cord = [center-fix_r*ppd center+fix_r*ppd];                     % coords for fixation point (center)

%% Background grating

for g = 1
    for f = 1:4
        turq{f,g} = imresize(imread([path 'Turq' num2str(f) '_' num2str(g) '.png']),1.5);
        purp{f,g} = imresize(imread([path 'Purple' num2str(f) '_' num2str(g) '.png']),1.5);
        yell{f,g} = imresize(imread([path 'Yellow' num2str(f) '_' num2str(g) '.png']),1.5);
    end
end

grey = imresize(imread([path 'Grey.png']),1.5);

CDcol = 1:12;

% motion details
duration = 4;
PresenSecs = 2;
ifi=Screen('GetFlipInterval', windowPr);
ifims = ifi*1000; %time in ms
nframes = round(1000*1/ifims)*PresenSecs; %number of frames to show the stimulus for

frame_count = 1;        % Use to count frames between letters
letter_count = 1;       % Use to keep track of which letter to display
response_count = 1;     % Use to keep track of responses
response_correct = 0;   % Use to keep track of button press feedback
oval_count = 1;         % Keep track of how long oval color was displayed
responses = [];         % Create empty responses matrix

%% Set up
speedl = 3;
sl = speedl*PresenSecs;
lf = nframes/sl;
lfr = 1:sl;
lframes = lfr*lf;

speedg = 5;
sg = speedg*2*PresenSecs;
gf = nframes/sg;
gfr = 1:sg;
gframes = gfr*gf;

% start the log file for reporting
logFID = fopen(['C:\Users\BiosemiStim\Desktop\HaighLab\' ID '_log.txt'],'at+');

greyRect = Screen('MakeTexture', windowPr, grey);

%% Start presentation

KbQueueCreate;

Screen('DrawTexture',windowPr,greyRect);
DrawFormattedText(windowPr, 'Please hit the space bar when you see', 'center', (rect(4)/8)*3);
DrawFormattedText(windowPr, 'an "A" followed by a "X"', 'center', (rect(4)/8)*4);
DrawFormattedText(windowPr, 'Press any key to continue', 'center', (rect(4)/8)*5);
Screen('Flip', windowPr); 
WaitSecs(.1);
KbWait;

pairord = repmat(1:4,3);
clearvars pressed firstPress

for b = 1:block_n
    
    randpairord = pairord(randperm(length(pairord)));
    t = CDcol(randperm(length(CDcol)));
    
    for j = 1:12
        
        randorder = order(randperm(length(order)));
        
        i=1;
        k=1;
    
        letters = randomletters(randperm(length(randomletters)));    
        letters(randorder(1):randorder(1)+1) = pairs(randpairord(j),:);
        secs0 = GetSecs;
        
        if t(j) < 5
            grating1 = Screen('MakeTexture', windowPr, turq{t(j),1});
        elseif t(j) > 4 && t(j) < 9
            grating1 = Screen('MakeTexture', windowPr, purp{t(j)-4,1});
        elseif t(j) > 8
            grating1 = Screen('MakeTexture', windowPr, yell{t(j)-8,1});
        end
        
            outputSingleScan(s, dec2binvec(t(j),8))
            outputSingleScan(s, [0 0 0 0 0 0 0 0])
            
            KbQueueStart;

        for n = 1:nframes
            frameindex = mod(n-1,nframes)+1;
            
            if gframes(k) > n && mod(k,2) == 0      
                 Screen('DrawTextures', windowPr, grating1);
            elseif gframes(k) > n && mod(k,2) == 1
                Screen('DrawTextures', windowPr, greyRect)
            end

            if gframes(k)==n && n < nframes                    
                k = k+1;
            end
            
            if n < lframes(i)-5 % leave 5 frames in between letter switch
                Screen('FillOval', windowPr, uint8([255,255,255]), fix_cord);
                Screen('DrawText', windowPr, letters(i), center(1)-13, center(2)-25, black);                
            else
                Screen('FillOval', windowPr, uint8([255,255,255]), fix_cord);
            end
            
            Screen('Flip', windowPr);
            
            %% check letter order
            if lframes(i)==n && n < nframes
                 szl = length(l);
                    l(szl+1) = letters(i);
                  i = i+1;
            end

        end
        
            outputSingleScan(s, dec2binvec(randpairord(j)+12,8)) 
            outputSingleScan(s, [0 0 0 0 0 0 0 0])
        
        [pressed, firstPress]=KbQueueCheck;
            szl = length(l);
            l(szl+1) = letters(i);
            pressedKeys=find(firstPress);
            if pressedKeys == 27
                Screen('CloseAll')
                fclose(logFID);  
                Priority(0);
            end
            
        Screen('DrawTexture', windowPr, greyRect);
        Screen('FillOval', windowPr, uint8([255,255,255]), fix_cord);
        Screen('Flip', windowPr);
        WaitSecs(1);
        
        %% Record responses
        sz = size(RT);
        RT(1,sz(2)+1) = b;
        RT(2,sz(2)+1) = j;
        RT(3,sz(2)+1) = t(j);
        RT(4,sz(2)+1) = randpairord(j);
        RT(5,sz(2)+1) = randorder(1);
        if pressed == 1  
           RT(6,sz(2)+1) = 1;
            RT(7,sz(2)+1) = max(firstPress)-secs0;
            press = 1;
            restime = max(firstPress)-secs0;
            if randorder(1) == 1
                adjResp = restime-0.330;
            elseif randorder(1) == 2
                adjResp = restime-0.660;
            elseif randorder(1) == 3
                adjResp = restime-0.990;
            elseif randorder(1) == 4
               adjResp = restime-1.320;
            else
                adjResp = restime-1.650;
            end
            RT(8,sz(2)+1) = adjResp;
        else  RT(6,sz(2)+1) = 0;
            RT(7,sz(2)+1) = 100;
            press = 0;
            restime = 100;
            adjResp = 100;
            RT(8,sz(2)+1) = adjResp;
        end
        
        % print to logfile:
        fprintf(logFID,['%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t\n']', speedg, speedl, j, b, t(j), randpairord(j), randorder(1), press, restime, adjResp);
        
        KbQueueFlush;
        clearvars pressed firstPress secs0 responded respondedRT
    end
    
    if b == block_n
        Screen('DrawTexture',windowPr,greyRect); 
        DrawFormattedText(windowPr, 'You have finished', 'center', (rect(4)/8)*3);
        Screen('Flip', windowPr); 
        WaitSecs(1);
        KbQueueStop;
        KbQueueRelease;
        Screen('CloseAll');
    elseif mod(3,b) == 3
        Screen('DrawTexture',windowPr,greyRect);
        DrawFormattedText(windowPr, 'Please take a break', 'center', (rect(4)/8)*3);
        DrawFormattedText(windowPr, 'Press any key to continue', 'center', (rect(4)/8)*4);
        Screen('Flip', windowPr); 
        WaitSecs(.1);
        KbWait;
        Screen('Flip', windowPr);
        Screen('DrawTexture', windowPr, greyRect);
        Screen('FillOval', windowPr, uint8([255,255,255]), fix_cord);
        Screen('Flip', windowPr);
        WaitSecs(1)
        KbQueueFlush;
    end
    clearvars pressed firstPress secs0 responded respondedRT
end

ShowCursor;

Priority(0);

fclose(logFID);
xlswrite([ID 'SSVEPwAXCPT_colour.xlsx'], RT);
Screen('CloseAll');
